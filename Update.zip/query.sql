ALTER TABLE `product_variant` ADD `hsn_code` VARCHAR(30) NULL DEFAULT NULL AFTER `breadth`;
ALTER TABLE `order_items` ADD `hsn_code` VARCHAR(30) NULL DEFAULT NULL AFTER `shipping_method`;
ALTER TABLE `offers` ADD `type` VARCHAR(20) NOT NULL AFTER `image`, ADD `type_id` INT(11) NOT NULL AFTER `type`;
ALTER TABLE `offers` ADD `offer_image_url` TEXT NULL DEFAULT NULL AFTER `type_id`;
UPDATE `settings` SET `value` = '' WHERE `variable` = 'doctor_brown';